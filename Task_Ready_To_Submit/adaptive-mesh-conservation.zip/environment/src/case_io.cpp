#include "../include/case_spec.h"
#include "../include/ic_loader.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void rstrip(char *s) {
    int n = (int)strlen(s);
    while (n > 0 && (s[n-1] == '\n' || s[n-1] == '\r' || s[n-1] == ' ' || s[n-1] == '\t')) {
        s[--n] = 0;
    }
}

static void parse_leaves(const char *val, ScenarioSpec *out) {
    int c = 0;
    const char *p = val;
    while (*p && c < MAX_COARSE) {
        int w = 0;
        int k = 0;
        while (*p && *p != '|') {
            if (*p >= '0' && *p <= '9') {
                w = w * 10 + (*p - '0');
            } else if (*p == ',') {
                if (k < MAX_LEAVES) out->leaf_weight[c][k++] = w;
                w = 0;
            }
            p++;
        }
        if (k < MAX_LEAVES) out->leaf_weight[c][k++] = w;
        out->leaf_count[c] = k;
        c++;
        if (*p == '|') p++;
    }
}

int load_case(const char *path, const char *section, ScenarioSpec *out) {
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    memset(out, 0, sizeof(*out));
    snprintf(out->name, sizeof(out->name), "%s", section);
    char want[64];
    snprintf(want, sizeof(want), "[%s]", section);
    int in_section = 0;
    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == '\n' || *p == '\r' || *p == 0) continue;
        rstrip(p);
        if (*p == '[') {
            in_section = (strcmp(p, want) == 0) ? 1 : 0;
            continue;
        }
        if (!in_section) continue;
        char *eq = strchr(p, '=');
        if (!eq) continue;
        char key[64];
        memset(key, 0, sizeof(key));
        int kl = (int)(eq - p);
        if (kl >= (int)sizeof(key)) kl = (int)sizeof(key) - 1;
        memcpy(key, p, kl);
        char *kt = key + kl - 1;
        while (kt >= key && (*kt == ' ' || *kt == '\t')) *kt-- = 0;
        char *v = eq + 1;
        while (*v == ' ' || *v == '\t') v++;
        if (strcmp(key, "name") == 0) {
            snprintf(out->name, sizeof(out->name), "%s", v);
        } else if (strcmp(key, "profile") == 0) {
            out->profile = atoi(v);
        } else if (strcmp(key, "n_coarse") == 0) {
            out->n_coarse = atoi(v);
        } else if (strcmp(key, "do_flux") == 0) {
            out->do_flux = atoi(v);
        } else if (strcmp(key, "do_collapse") == 0) {
            out->do_collapse = atoi(v);
        } else if (strcmp(key, "do_restart") == 0) {
            out->do_restart = atoi(v);
        } else if (strcmp(key, "leaves") == 0) {
            parse_leaves(v, out);
        }
    }
    fclose(fp);
    if (out->n_coarse <= 0 || out->n_coarse > MAX_COARSE) return -2;
    return 0;
}

const char *app_root(void) {
    const char *r = getenv("APP_ROOT");
    return (r && r[0]) ? r : "/app";
}

int load_init(int profile_id, int n_coarse, CellGrid *out) {
    if (n_coarse <= 0 || n_coarse > MAX_CELLS) return -1;
    char letter = (char)('a' + profile_id);
    char path[256];
    snprintf(path, sizeof(path), "%s/data/init/profile_%c.dat", app_root(), letter);
    FILE *fp = fopen(path, "r");
    if (!fp) return -2;
    out->n = 0;
    char line[256];
    while (fgets(line, sizeof(line), fp) && out->n < n_coarse) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == '\n' || *p == '\r' || *p == 0) continue;
        double q0 = 0.0, q1 = 0.0, q2 = 0.0;
        if (sscanf(p, "%lf %lf %lf", &q0, &q1, &q2) != 3) continue;
        int i = out->n;
        out->cells[i].idx = i;
        out->cells[i].tier = 0;
        out->cells[i].parent = -1;
        out->cells[i].vol = 1.0;
        out->cells[i].q[0] = q0;
        out->cells[i].q[1] = q1;
        out->cells[i].q[2] = q2;
        out->n++;
    }
    fclose(fp);
    if (out->n != n_coarse) return -3;
    return 0;
}
