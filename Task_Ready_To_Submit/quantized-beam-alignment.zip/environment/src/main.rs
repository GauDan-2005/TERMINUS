mod a0;
mod b1;
mod c2;
mod d3;
mod e4;
mod f5;
mod g6;

use std::env;
use std::fs;

struct Case {
    name: &'static str,
    packed: bool,
    group: bool,
    reuse: bool,
    seq: Vec<usize>,
    rows: Vec<Vec<i32>>,
}

fn cases() -> Vec<Case> {
    vec![
        Case { name: "alpha", packed: false, group: true, reuse: false, seq: vec![0, 1], rows: vec![vec![21, 10, 4], vec![15, 8, 6]] },
        Case { name: "beta", packed: true, group: false, reuse: false, seq: vec![0], rows: vec![vec![10, 4, 1]] },
        Case { name: "gamma", packed: true, group: true, reuse: false, seq: vec![0, 1], rows: vec![vec![8, 3, 2], vec![6, 5, 1]] },
        Case { name: "delta", packed: true, group: true, reuse: false, seq: vec![1, 0], rows: vec![vec![7, 4, 2], vec![5, 6, 3]] },
        Case { name: "epsilon", packed: true, group: true, reuse: true, seq: vec![1, 0, 2], rows: vec![vec![4, 7, 2], vec![9, 2, 3], vec![3, 8, 1]] },
        Case { name: "zeta", packed: false, group: true, reuse: true, seq: vec![2, 0, 1], rows: vec![vec![12, 9, 5], vec![18, 4, 7], vec![10, 6, 8]] },
    ]
}

fn token(sum: i32, slot: usize, packed: bool, group: bool, reuse: bool) -> i32 {
    let mut v = sum + (slot as i32) * 7;
    if packed { v += 3; }
    if group { v += 5; }
    if reuse { v += 11; }
    v.rem_euclid(101)
}

fn render_nums(a: &[i32]) -> String {
    a.iter().map(|x| x.to_string()).collect::<Vec<_>>().join(",")
}

fn render_usize(a: &[usize]) -> String {
    a.iter().map(|x| x.to_string()).collect::<Vec<_>>().join(",")
}

fn run_one(c: &Case) -> String {
    let meta = a0::A0::new();
    let mut h = b1::B0::new(c.rows.len());
    let mut local = c2::C0::new(c.rows.len().max(1));
    let moved = b1::bx(&mut h, &c.seq);
    let base_rows: Vec<Vec<i32>> = c.rows.iter().enumerate().map(|(i, row)| {
        if c.packed { a0::ax(&meta, row, i) } else { row.clone() }
    }).collect();
    if c.packed {
        for (i, row) in c.rows.iter().enumerate() {
            if base_rows[i] != a0::ax_ref(&meta, row) {
                eprintln!(
                    "sanity[a0]: expansion for case {} diverges from the retained reference",
                    c.name
                );
                break;
            }
        }
    }
    let chosen = d3::dx(&(0..base_rows.len()).map(|i| i as i32).collect::<Vec<_>>(), &c.seq);
    let mut vals = Vec::new();
    let mut trace = Vec::new();
    for (pos, src) in c.seq.iter().enumerate() {
        let handle = moved[pos];
        let acc = c2::cx(&mut local, handle, &base_rows[*src]);
        vals.push(token(acc, handle, c.packed, c.group, c.reuse));
        trace.push(handle);
    }
    let mut sink = e4::E0::new();
    e4::ex(&mut sink, c.name, &vals, &trace);
    let _display = f5::view(&vals);
    let _shape = g6::describe(&trace);
    format!("{{\"case\":\"{}\",\"produced\":[{}],\"slot_trace\":[{}],\"order_used\":[{}],\"packed\":{},\"grouped\":{},\"reuse\":{},\"selected\":[{}]}}",
        c.name, render_nums(&vals), render_usize(&trace), render_usize(&c.seq), c.packed, c.group, c.reuse, render_nums(&chosen))
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let out = args.get(1).cloned().unwrap_or_else(|| "/app/output/raw.json".to_string());
    let rows = cases().iter().map(run_one).collect::<Vec<_>>().join(",");
    let body = format!("{{\"raw\":[{}]}}\n", rows);
    if let Some(parent) = std::path::Path::new(&out).parent() {
        fs::create_dir_all(parent).unwrap();
    }
    fs::write(out, body).unwrap();
}
