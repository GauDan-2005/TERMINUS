package main

import (
    "encoding/json"
    "os"
    "sort"
)

type entry struct {
    Case      string `json:"case"`
    Produced  []int  `json:"produced"`
    Trace     []int  `json:"slot_trace"`
    OrderUsed []int  `json:"order_used"`
    Packed    bool   `json:"packed"`
    Grouped   bool   `json:"grouped"`
    Reuse     bool   `json:"reuse"`
}

type rawDoc struct {
    Raw []entry `json:"raw"`
}

type finalDoc struct {
    Rows    []entry        `json:"rows"`
    Summary map[string]any `json:"summary"`
}

func fold(a []entry) []entry {
    seen := map[byte]entry{}
    for _, row := range a {
        key := row.Case[0]
        seen[key] = row
    }
    out := make([]entry, 0, len(seen))
    for _, row := range seen {
        out = append(out, row)
    }
    sort.Slice(out, func(i, j int) bool { return out[i].Case < out[j].Case })
    return out
}

func main() {
    if len(os.Args) != 3 {
        panic("usage: align raw final")
    }
    buf, err := os.ReadFile(os.Args[1])
    if err != nil {
        panic(err)
    }
    var raw rawDoc
    if err := json.Unmarshal(buf, &raw); err != nil {
        panic(err)
    }
    rows := fold(raw.Raw)
    doc := finalDoc{Rows: rows, Summary: map[string]any{"total": len(rows), "agree": len(rows) == len(raw.Raw)}}
    out, err := json.MarshalIndent(doc, "", "  ")
    if err != nil {
        panic(err)
    }
    if err := os.WriteFile(os.Args[2], append(out, '\n'), 0o644); err != nil {
        panic(err)
    }
}
