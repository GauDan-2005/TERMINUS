#include "../include/block.h"

#include <stddef.h>

void xa0(Block *a, size_t b) {
    size_t *hdr = (size_t *)(void *)(a->base + a->off);
    size_t *ftr;
    hdr[0] = b;
    hdr[1] = 0;
    ftr = (size_t *)(void *)(a->base + a->off + (b / 2));
    ftr[0] = b;
}

size_t tag_read_size(const Block *a) {
    size_t *hdr = (size_t *)(void *)(a->base + a->off);
    return hdr[0];
}

int z_is_flag(const Block *a) {
    size_t *hdr = (size_t *)(void *)(a->base + a->off);
    return (int)(hdr[1] & 1);
}

void z_set_flag(Block *a, int flag) {
    size_t *hdr = (size_t *)(void *)(a->base + a->off);
    if (flag) {
        hdr[1] |= 1;
    } else {
        hdr[1] &= ~(size_t)1;
    }
}

size_t tag_read_footer(const Block *a, size_t total) {
    size_t *ftr = (size_t *)(void *)(a->base + a->off + (total / 2));
    return ftr[0];
}
