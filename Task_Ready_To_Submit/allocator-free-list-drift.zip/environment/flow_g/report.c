#include "../include/report.h"

#include <stdio.h>
#include <string.h>

static void esc(FILE *fp, const char *s) {
    fputc('"', fp);
    for (const char *p = s; *p; p++) {
        if (*p == '"' || *p == '\\') {
            fputc('\\', fp);
        }
        fputc(*p, fp);
    }
    fputc('"', fp);
}

static void write_case(FILE *fp, const CaseResult *res, int last) {
    FILE *led = fopen(res->ledger_path, "w");
    fprintf(fp, "    {\n      \"name\": ");
    esc(fp, res->name);
    fprintf(fp, ",\n      \"ok\": %s,\n", res->ok ? "true" : "false");
    fprintf(fp, "      \"heap_sig\": %zu,\n", res->heap_sig);
    fprintf(fp, "      \"fl_count\": %d,\n", res->fl_count);
    fprintf(fp, "      \"fl_sig\": %zu,\n", res->fl_sig);
    fprintf(fp, "      \"byte_total\": %zu,\n", res->byte_total);
    fprintf(fp, "      \"ledger\": ");
    esc(fp, res->ledger_path);
    fprintf(fp, ",\n      \"steps\": [\n");
    for (int i = 0; i < res->step_count; i++) {
        const StepRec *st = &res->steps[i];
        fprintf(fp,
                "        {\"seq\": %d, \"op\": ", st->seq);
        esc(fp, st->op);
        fprintf(fp,
                ", \"index\": %d, \"size\": %zu, \"result_index\": %d, \"heap_sig\": %zu, "
                "\"fl_count\": %d, \"fl_sig\": %zu, \"byte_total\": %zu}",
                st->index, st->size, st->result_index, st->heap_sig, st->fl_count, st->fl_sig,
                st->byte_total);
        if (i + 1 < res->step_count) {
            fprintf(fp, ",");
        }
        fprintf(fp, "\n");
        if (led) {
            fprintf(led,
                    "{\"seq\":%d,\"op\":", st->seq);
            esc(led, st->op);
            fprintf(led,
                    ",\"index\":%d,\"size\":%zu,\"result_index\":%d,\"heap_sig\":%zu,"
                    "\"fl_count\":%d,\"fl_sig\":%zu,\"byte_total\":%zu}\n",
                    st->index, st->size, st->result_index, st->heap_sig, st->fl_count,
                    st->fl_sig, st->byte_total);
        }
    }
    fprintf(fp, "      ]\n    }");
    if (!last) {
        fprintf(fp, ",");
    }
    fprintf(fp, "\n");
    if (led) {
        fclose(led);
    }
}

int emit_e(const CaseResult *res, const char *audit_path) {
    FILE *fp = fopen(audit_path, "w");
    if (!fp) {
        return -1;
    }
    fprintf(fp, "{\n  \"cases\": [\n");
    write_case(fp, res, 1);
    fprintf(fp, "  ]\n}\n");
    fclose(fp);
    return 0;
}

int emit_matrix(const CaseResult *cases, int count, const char *audit_path) {
    FILE *fp = fopen(audit_path, "w");
    int i;
    if (!fp) {
        return -1;
    }
    fprintf(fp, "{\n  \"cases\": [\n");
    for (i = 0; i < count; i++) {
        write_case(fp, &cases[i], i + 1 == count);
    }
    fprintf(fp, "  ]\n}\n");
    fclose(fp);
    return 0;
}
