#!/bin/bash
set -euo pipefail
out="/app/output/resume-audit.json"
work=""
one_case=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --out) out="$2"; shift 2 ;;
    --work) work="$2"; shift 2 ;;
    --case) one_case="$2"; shift 2 ;;
    *) shift ;;
  esac
done
mkdir -p "$(dirname "$out")"
make -s -C /app build
args=("--out" "$out")
if [ -n "$work" ]; then
  args+=("--root" "$work")
fi
if [ -n "$one_case" ]; then
  args+=("--case" "$one_case")
fi
/app/bin/rogctl "${args[@]}"
