package b1

import (
	"sort"

	"staged.local/snapshot/internal/f5"
)

type rowX = f5.Row

func fold_b(a []rowX, b uint64) ([]rowX, error) {
	out := make([]rowX, len(a))
	copy(out, a)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].Seq < out[j].Seq
	})
	if b&1 == 1 {
		for left, right := 0, len(out)-1; left < right; left, right = left+1, right-1 {
			out[left], out[right] = out[right], out[left]
		}
	}
	return out, nil
}

func FoldRows(rows []f5.Row, profile f5.Profile) ([]f5.Row, error) {
	var flags uint64
	if profile.Restart && profile.Ordered {
		flags |= 1
	}
	return fold_b(rows, flags)
}
