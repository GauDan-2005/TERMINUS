package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"staged.local/snapshot/internal/a0"
	"staged.local/snapshot/internal/c2"
	"staged.local/snapshot/internal/e4"
	"staged.local/snapshot/internal/f5"
)

func accountingEqual(a, b []f5.AccountItem) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i].Path != b[i].Path || a[i].Bytes != b[i].Bytes || a[i].Period != b[i].Period {
			return false
		}
	}
	return true
}

func accountingMatchesDisk(root string, items []f5.AccountItem) bool {
	for _, item := range items {
		path := filepath.Join(root, item.Path)
		st, err := os.Stat(path)
		if err != nil {
			return false
		}
		if !st.Mode().IsRegular() {
			return false
		}
		if int(st.Size()) != item.Bytes {
			return false
		}
	}
	return true
}

func runCase(base string, name string) (f5.CaseResult, error) {
	profile := f5.ProfileFor(name)
	caseDir := filepath.Join(base, name)
	if err := os.RemoveAll(caseDir); err != nil {
		return f5.CaseResult{}, err
	}
	source := filepath.Join(caseDir, "source")
	restored := filepath.Join(caseDir, "restored")
	if err := os.MkdirAll(source, 0o755); err != nil {
		return f5.CaseResult{}, err
	}
	if err := os.MkdirAll(restored, 0o755); err != nil {
		return f5.CaseResult{}, err
	}
	if err := a0.CreateTree(source, profile); err != nil {
		return f5.CaseResult{}, err
	}
	rows, err := a0.RowsFromTree(source, profile)
	if err != nil {
		return f5.CaseResult{}, err
	}
	if err := a0.Materialize(rows, restored, profile); err != nil {
		return f5.CaseResult{}, err
	}
	sourceDigest, err := e4.Digest(source)
	if err != nil {
		return f5.CaseResult{}, err
	}
	restoredDigest, err := e4.Digest(restored)
	if err != nil {
		return f5.CaseResult{}, err
	}
	sourceGroups, err := e4.Groups(source)
	if err != nil {
		return f5.CaseResult{}, err
	}
	restoredGroups, err := e4.Groups(restored)
	if err != nil {
		return f5.CaseResult{}, err
	}
	accounting, err := c2.ItemsC(source, profile)
	if err != nil {
		return f5.CaseResult{}, err
	}
	restoredAccounting, err := c2.ItemsC(restored, profile)
	if err != nil {
		return f5.CaseResult{}, err
	}
	digestsMatch := sourceDigest == restoredDigest
	groupsMatch := fmt.Sprint(sourceGroups) == fmt.Sprint(restoredGroups)
	accountingMatch := accountingEqual(accounting, restoredAccounting)
	diskMatch := accountingMatchesDisk(source, accounting) && accountingMatchesDisk(restored, restoredAccounting)
	ok := digestsMatch && groupsMatch && accountingMatch && diskMatch
	return f5.CaseResult{
		Name:       name,
		Source:     source,
		Restored:   restored,
		OK:         ok,
		Digest:     f5.DigestPair{Source: sourceDigest, Restored: restoredDigest},
		Groups:     f5.GroupPair{Source: sourceGroups, Restored: restoredGroups},
		Accounting: accounting,
	}, nil
}

func main() {
	outPath := flag.String("out", "/app/output/restore-audit.json", "audit output")
	workPath := flag.String("work", "", "workspace root")
	oneCase := flag.String("case", "", "single case")
	flag.Parse()

	base := *workPath
	if base == "" {
		tmp, err := os.MkdirTemp("", "staged-snapshot-")
		if err != nil {
			panic(err)
		}
		base = tmp
	}
	if err := os.MkdirAll(base, 0o755); err != nil {
		panic(err)
	}
	names := []string{"alpha", "beta", "gamma", "delta", "epsilon", "zeta"}
	if *oneCase != "" {
		names = []string{*oneCase}
	}
	sort.Strings(names)
	report := f5.Report{Cases: []f5.CaseResult{}}
	for _, name := range names {
		result, err := runCase(base, name)
		if err != nil {
			panic(err)
		}
		report.Cases = append(report.Cases, result)
	}
	if err := os.MkdirAll(filepath.Dir(*outPath), 0o755); err != nil {
		panic(err)
	}
	encoded, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		panic(err)
	}
	if err := os.WriteFile(*outPath, append(encoded, '\n'), 0o644); err != nil {
		panic(err)
	}
}
