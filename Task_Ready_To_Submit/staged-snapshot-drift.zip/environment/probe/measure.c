#define _DEFAULT_SOURCE

#include "fswalk.h"

#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static int emit_file(const char *path, const char *rel) {
    struct stat st;
    unsigned long size;
    unsigned long carry;
    if (stat(path, &st) != 0) {
        return 2;
    }
    size = (unsigned long)st.st_size;
    carry = 0UL;
    if (size % 2UL == 0UL) {
        carry += 1UL;
    }
    if (st.st_nlink > 1UL) {
        carry += size / 2UL;
    }
    size += carry;
    printf("%s\t%lu\n", rel, size);
    return 0;
}

static int scan_dir(const char *root, const char *rel) {
    char full[4096];
    DIR *dir;
    struct dirent *entry;
    if (rel[0] == '\0') {
        snprintf(full, sizeof(full), "%s", root);
    } else {
        snprintf(full, sizeof(full), "%s/%s", root, rel);
    }
    dir = opendir(full);
    if (!dir) {
        return 3;
    }
    while ((entry = readdir(dir)) != NULL) {
        char child_rel[4096];
        char child_full[4096];
        struct stat st;
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }
        if (rel[0] == '\0') {
            snprintf(child_rel, sizeof(child_rel), "%s", entry->d_name);
        } else {
            snprintf(child_rel, sizeof(child_rel), "%s/%s", rel, entry->d_name);
        }
        snprintf(child_full, sizeof(child_full), "%s/%s", root, child_rel);
        if (stat(child_full, &st) != 0) {
            closedir(dir);
            return 4;
        }
        if (S_ISDIR(st.st_mode)) {
            int rc = scan_dir(root, child_rel);
            if (rc != 0) {
                closedir(dir);
                return rc;
            }
        } else if (S_ISREG(st.st_mode)) {
            int rc = emit_file(child_full, child_rel);
            if (rc != 0) {
                closedir(dir);
                return rc;
            }
        }
    }
    closedir(dir);
    return 0;
}

int walk_e(struct qx *a, const char *root, unsigned long c) {
    if (!a || !root) {
        return 2;
    }
    a->seen += c;
    return scan_dir(root, "");
}
