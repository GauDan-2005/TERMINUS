use crate::io::split_subject_object_mode;
use crate::k1_b::fold_b;
use crate::k3_d::lift_d;
use crate::k5_f::cast_f;
use crate::model::{CaseReport, Decision, Event, State};

pub fn phase_a(a: &mut State, b: &Event, c: &mut CaseReport) -> Result<(), String> {
    match b.kind.as_str() {
        "grant" => {
            let (object, mode) = b
                .right
                .split_once('/')
                .ok_or_else(|| format!("bad grant row {}", b.right))?;
            a.direct
                .insert((b.left.clone(), object.to_string(), mode.to_string()));
            a.clock += 1;
            Ok(())
        }
        "delegate" => {
            a.chain.insert(b.right.clone(), b.left.clone());
            a.clock += 1;
            Ok(())
        }
        "revoke" => fold_b(a, &b.left),
        "batch" => {
            a.group_active = b.left.clone();
            a.group_slot.clear();
            Ok(())
        }
        "end" => {
            a.group_active.clear();
            a.group_slot.clear();
            Ok(())
        }
        "check" => {
            let (subject, object, mode) = split_subject_object_mode(&b.right)?;
            let row = if a.group_active.is_empty() {
                wrap_g(a, &b.left, &subject, &object, &mode)
            } else {
                lift_d(a, &b.left, &subject, &object, &mode)
            };
            let (row, note) = cast_f(a, row, true);
            c.decisions.push(row);
            if let Some(note) = note {
                c.stale.push(note);
            }
            Ok(())
        }
        other => Err(format!("unknown trace row {other}")),
    }
}

fn wrap_g(a: &mut State, label: &str, subject: &str, object: &str, mode: &str) -> Decision {
    use crate::k2_c::emit_c;
    use crate::k4_e::mote_e;

    let tick = a.tick_for(subject);
    if let Some(outcome) = emit_c(a, subject, object, mode) {
        let via = if outcome == "allow" {
            mote_e(a, subject, object, mode).1
        } else {
            String::new()
        };
        let mut row = Decision::blank(label, subject, object, mode, tick);
        row.outcome = outcome;
        row.via = via;
        return row;
    }
    let (outcome, via) = mote_e(a, subject, object, mode);
    a.store.insert(
        crate::model::State::slot_key(object, mode),
        outcome.clone(),
    );
    let mut row = Decision::blank(label, subject, object, mode, tick);
    row.outcome = outcome;
    row.via = via;
    row
}
